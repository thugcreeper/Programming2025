#pragma once

class Vector {
public:
    int m;
    int * content;
    
    void show();
    
};
