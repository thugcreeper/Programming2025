#include "Detection.hpp"
#include "Common.hpp"

#include <iostream>

using namespace std;

int Detection::isDeadlock(Vector resource, Matrix allocation, Matrix request) {
    
    Vector available = Common::calculateAvailable(resource, allocation);
    
    Vector work;
    work.m = available.m;
    work.content = new int[work.m];
    for (int i = 0; i < available.m; i++) {
        work.content[i] = available.content[i];
    }
    
    Vector finish;
    finish.m = allocation.n;
    finish.content = new int[finish.m];
    for (int i = 0; i < finish.m; i++) {
        finish.content[i] = 0;
    }
    
    for (int i = 0; i < allocation.n; i++) {
        Vector allocV = Common::getOneRowFromMatrix(allocation, i);
        if (Common::vectorZero(allocV) == 1) {
            finish.content[i] = 1;
        }
    }
    
    int threadI = -1;
    do {
        threadI = -1;
        
        for (int i = 0; i < finish.m; i++) {
            
            Vector reqV = Common::getOneRowFromMatrix(request, i);
            
            if (finish.content[i] == 0 && Common::lessThanOrEqualToVector(reqV, work)) {
                threadI = i;
                break;
            }
        }
                
        if (threadI != -1) {
            Vector allocV = Common::getOneRowFromMatrix(allocation, threadI);
            Common::vectorAddition(work, allocV);
            finish.content[threadI] = 1;
        }
    } while (threadI != -1);
    
    for (int i = 0; i < finish.m; i++) {
        if (finish.content[i] == 0) {
            return 1;
        }
    }
    return 0;
}


