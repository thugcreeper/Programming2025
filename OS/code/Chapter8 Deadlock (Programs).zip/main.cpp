#include "ReadFile.hpp"
#include "Banker.hpp"
#include "Detection.hpp"

#include <iostream>

using namespace std;

void runDeadlockAvoidanceExample();
void runDeadlockDetectionExample();

int main(int argc, const char * argv[]) {
    
    // runDeadlockAvoidanceExample();
    runDeadlockDetectionExample();
    
    return 0;
}

void runDeadlockDetectionExample() {
    Vector resource = ReadFile::readVectorFile("Resource_Detection.txt");
    Matrix request = ReadFile::readMatrixFile("Request_Detection.txt");
    Matrix allocation = ReadFile::readMatrixFile("Allocation_Detection.txt");
    
    int deadlockflag = Detection::isDeadlock(resource, allocation, request);
    
    cout << "Deadlock: " << deadlockflag << "\n";
    
}

void runDeadlockAvoidanceExample() {
    Vector resource = ReadFile::readVectorFile("Resource_Avoidance.txt");
    Matrix max = ReadFile::readMatrixFile("Max_Avoidance.txt");
    Matrix allocation = ReadFile::readMatrixFile("Allocation_Avoidance.txt");
    
    int safeflag = Banker::isSafe(resource, max, allocation);
    cout << "Current State: " << safeflag << "\n";
    
    /* Wiki */
    Vector request1;
    request1.m = resource.m;
    request1.content = new int[request1.m];
    request1.content[0] = 0;
    request1.content[1] = 0;
    request1.content[2] = 1;
    request1.content[3] = 0;
    int threadI = 2; // Process 3
    
    int requestflag = Banker::request(request1, threadI, resource, max, allocation);
    
    cout << "Request State: " << requestflag << "\n";
    
    Vector request2;
    request2.m = resource.m;
    request2.content = new int[request2.m];
    request2.content[0] = 0;
    request2.content[1] = 1;
    request2.content[2] = 0;
    request2.content[3] = 0;
    threadI = 1; // Process 2
    
    
    requestflag = Banker::request(request2, threadI, resource, max, allocation);
    
    cout << "Request State: " << requestflag << "\n";
    
    /* Text Book Example */
    /*
    Vector request1;
    request1.m = resource.m;
    request1.content = new int[request1.m];
    request1.content[0] = 1;
    request1.content[1] = 0;
    request1.content[2] = 2;
    int threadI = 1;
    
    int requestflag = Banker::request(request1, threadI, resource, max, allocation);
    
    cout << "Request State: " << requestflag << "\n";
    
    Vector request2;
    request2.m = resource.m;
    request2.content = new int[request2.m];
    request2.content[0] = 3;
    request2.content[1] = 3;
    request2.content[2] = 0;
    threadI = 4;
    
    requestflag = Banker::request(request2, threadI, resource, max, allocation);
    
    cout << "Request State: " << requestflag << "\n";
     
    Vector request3;
    request3.m = resource.m;
    request3.content = new int[request3.m];
    request3.content[0] = 0;
    request3.content[1] = 2;
    request3.content[2] = 0;
    threadI = 0;
    
    requestflag = Banker::request(request3, threadI, resource, max, allocation);
    
    cout << "Request State: " << requestflag << "\n";
    */
}
