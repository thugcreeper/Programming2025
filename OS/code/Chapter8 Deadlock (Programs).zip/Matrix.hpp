#pragma once

class Matrix {
public:
    int n;
    int m;
    int ** content;
    
    void show();
};
