#include "Matrix.hpp"
#include "Vector.hpp"

class Banker {
public:
    static int isSafe(Vector resource, Matrix max, Matrix allocation);
    static int request(Vector request, int threadI, Vector resource, Matrix max, Matrix allocation);
};


