#include "ReadFile.hpp"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

Matrix ReadFile::readMatrixFile(const char* filename) {
    string line;
    ifstream matrixFile(filename);
    
    int n = 0;
    int m = 0;
    
    if (matrixFile.is_open()) {
        string line;
        while(getline(matrixFile, line)) {
            string token;
            m = 0;
            do {
                token = line.substr(0, line.find(' '));
                if (token.length() > 0) {
                    m++;
                }
                line.erase(0, token.length()+1);
            } while(token.length() > 0);
            n++;
        }
        matrixFile.close();
    } else {
        cout << "Unable to open " << filename << ".\n";
        Matrix fail;
        fail.n = -1;
        fail.m = -1;
        fail.content = NULL;
        return fail;
    }
    
    int ** content = new int * [n];
    for(int i = 0; i < n; i++) {
        content[i] = new int[m];
    }
    
    n = 0;
    m = 0;
    
    matrixFile.open(filename);
    if (matrixFile.is_open()) {
        string line;
        while(getline(matrixFile, line)) {
            string token;
            m = 0;
            do {
                token = line.substr(0, line.find(' '));
                if (token.length() > 0) {
                    content[n][m] = stoi(token);
                    m++;
                }
                line.erase(0, token.length()+1);
            } while(token.length() > 0);
            n++;
        }
        matrixFile.close();
    } else {
        cout << "Unable to open " << filename << ".\n";
        Matrix fail;
        fail.n = -1;
        fail.m = -1;
        fail.content = NULL;
        return fail;
    }
    
    Matrix matrix;
    matrix.n = n;
    matrix.m = m;
    matrix.content = content;
    
    return matrix;
}

Vector ReadFile::readVectorFile(const char* filename) {
    string line;
    ifstream vectorFile(filename);
    
    int n = 0;
    
    if (vectorFile.is_open()) {
        string line;
        getline(vectorFile, line);
        string token;
        n = 0;
        do {
            token = line.substr(0, line.find(' '));
            if (token.length() > 0) {
                n++;
            }
            line.erase(0, token.length()+1);
        } while(token.length() > 0);
        vectorFile.close();
    } else {
        cout << "Unable to open " << filename << ".\n";
        Vector fail;
        fail.m = -1;
        fail.content = NULL;
        return fail;
    }
    
    int * content = new int[n];
    
    vectorFile.open(filename);
    if (vectorFile.is_open()) {
        string line;
        getline(vectorFile, line);
        string token;
        n = 0;
        do {
            token = line.substr(0, line.find(' '));
            if (token.length() > 0) {
                content[n] = stoi(token);
                n++;
            }
            line.erase(0, token.length()+1);
        } while(token.length() > 0);
        vectorFile.close();
    } else {
        cout << "Unable to open " << filename << ".\n";
        Vector fail;
        fail.m = -1;
        fail.content = NULL;
        return fail;
    }
    
    Vector vector;
    vector.m = n;
    vector.content = content;
    
    return vector;
}

