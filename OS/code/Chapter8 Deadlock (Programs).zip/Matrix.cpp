#include "Matrix.hpp"

#include <iostream>

using namespace std;

void Matrix::show() {
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cout << content[i][j] << " ";
        }
        cout << "\n";
    }
    
}
