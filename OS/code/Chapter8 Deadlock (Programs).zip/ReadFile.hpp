#include "Matrix.hpp"
#include "Vector.hpp"

class ReadFile {
public:
    static Matrix readMatrixFile(const char* filename);
    static Vector readVectorFile(const char* filename);
};

