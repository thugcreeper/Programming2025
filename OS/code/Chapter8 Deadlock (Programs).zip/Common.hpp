#include "Matrix.hpp"
#include "Vector.hpp"

class Common {
public:
    static Vector calculateAvailable(Vector resource, Matrix allocation);
    static Matrix calculateNeed(Matrix max, Matrix allocation);
    static int lessThanOrEqualToVector(Vector v1, Vector v2);
    static Vector getOneRowFromMatrix(Matrix matrix, int index);
    static void vectorAddition(Vector v1, Vector v2);
    static void vectorSubtraction(Vector v1, Vector v2);
    static int vectorZero(Vector v);
};
