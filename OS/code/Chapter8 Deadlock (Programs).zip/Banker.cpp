#include "Banker.hpp"
#include "Common.hpp"

#include <iostream>

using namespace std;

int Banker::request(Vector request, int threadI, Vector resource, Matrix max, Matrix allocation) {
    
    Vector available = Common::calculateAvailable(resource, allocation);
    Matrix need = Common::calculateNeed(max, allocation);

    Vector needV = Common::getOneRowFromMatrix(need, threadI);

    if (Common::lessThanOrEqualToVector(request, needV) != 1) {
        return -1;
    }
    
    if (Common::lessThanOrEqualToVector(request, available) != 1) {
        return -2;
    }
        
    for (int j = 0; j < request.m; j++) {
        allocation.content[threadI][j] += request.content[j];
    }
    
    if (isSafe(resource, max, allocation) == 0) {
        for (int j = 0; j < request.m; j++) {
            allocation.content[threadI][j] -= request.content[j];
        }
        return 0;
    }
    return 1;
}

int Banker::isSafe(Vector resource, Matrix max, Matrix allocation) {
    
    Vector available = Common::calculateAvailable(resource, allocation);
    Matrix need = Common::calculateNeed(max, allocation);
    
    Vector work;
    work.m = available.m;
    work.content = new int[work.m];
    for (int i = 0; i < available.m; i++) {
        work.content[i] = available.content[i];
    }
    
    Vector finish;
    finish.m = max.n;
    finish.content = new int[finish.m];
    for (int i = 0; i < finish.m; i++) {
        finish.content[i] = 0;
    }
    
    int threadI = -1;
    do {
        threadI = -1;
        
        for (int i = 0; i < finish.m; i++) {
            
            Vector needV = Common::getOneRowFromMatrix(need, i);
            
            if (finish.content[i] == 0 && Common::lessThanOrEqualToVector(needV, work)) {
                threadI = i;
                break;
            }
        }
                
        if (threadI != -1) {
            Vector allocV = Common::getOneRowFromMatrix(allocation, threadI);
            Common::vectorAddition(work, allocV);
            finish.content[threadI] = 1;
        }
    } while (threadI != -1);
    
    for (int i = 0; i < finish.m; i++) {
        if (finish.content[i] == 0) {
            return 0;
        }
    }
    return 1;    
}




