#include "Vector.hpp"

#include <iostream>

using namespace std;

void Vector::show() {
    
    for (int i = 0; i < m; i++) {
        cout << content[i] << " ";
    }
    cout << "\n";
}
