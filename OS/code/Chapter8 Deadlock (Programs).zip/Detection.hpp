#include "Matrix.hpp"
#include "Vector.hpp"

class Detection {
public:
    static int isDeadlock(Vector resource, Matrix allocation, Matrix request);
};
