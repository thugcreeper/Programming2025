#include "Common.hpp"

#include <iostream>

using namespace std;

int Common::vectorZero(Vector v) {
    for (int i = 0; i < v.m; i ++) {
        if (v.content[i] != 0) {
            return 0;
        }
    }
    return 1;
}

void Common::vectorAddition(Vector v1, Vector v2) {
    for (int i = 0; i < v1.m; i ++) {
        v1.content[i] += v2.content[i];
    }
}

void Common::vectorSubtraction(Vector v1, Vector v2) {
    for (int i = 0; i < v1.m; i ++) {
        v1.content[i] -= v2.content[i];
    }
}

Vector Common::getOneRowFromMatrix(Matrix matrix, int index) {
    
    Vector v;
    v.m = matrix.m;
    v.content = new int[v.m];
    
    for (int i = 0; i < v.m; i++) {
        v.content[i] = matrix.content[index][i];
    }
    return v;
}
                

int Common::lessThanOrEqualToVector(Vector v1, Vector v2) {
    
    for (int i = 0; i < v1.m; i++) {
        if (v1.content[i] > v2.content[i]) {
            return 0;
        }
    }
    return 1;
}

Matrix Common::calculateNeed(Matrix max, Matrix allocation) {
    
    Matrix need;
    
    need.n = max.n;
    need.m = max.m;
    
    need.content = new int * [need.n];
    for(int i = 0; i < need.n; i++) {
        need.content[i] = new int[need.m];
    }
    
    for (int i = 0; i < need.n; i++) {
        for (int j = 0; j < need.m; j++) {
            need.content[i][j] = max.content[i][j] - allocation.content[i][j];
        }
    }
    return need;
}

Vector Common::calculateAvailable(Vector resource, Matrix allocation) {

    Vector available;
    
    available.m = allocation.m;
    
    available.content = new int[available.m];
    
    int * ralloc = new int[available.m];
    
    for (int j = 0; j < allocation.m; j++) {
        ralloc[j] = 0;
        for (int i = 0; i < allocation.n; i++) {
            ralloc[j] += allocation.content[i][j];
        }
    }
    for (int j = 0; j < allocation.m ; j++) {
        available.content[j] = resource.content[j] - ralloc[j];
    }
    
    return available;
}

